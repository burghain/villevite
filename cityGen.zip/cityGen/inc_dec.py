def increment(x):
    return x + 1


def decrement(x):
    return x - 1
